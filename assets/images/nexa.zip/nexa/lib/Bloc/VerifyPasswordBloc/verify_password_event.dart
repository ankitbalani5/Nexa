// part of 'verify_password_bloc.dart';
//
// @immutable
// sealed class VerifyPasswordEvent {}
// class VerifyPasswordNewEvent extends VerifyPasswordEvent {
//   String credentials;
//   VerifyPasswordNewEvent(this.credentials);
// }
