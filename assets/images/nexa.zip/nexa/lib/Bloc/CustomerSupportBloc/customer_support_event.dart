part of 'customer_support_bloc.dart';

@immutable
abstract class CustomerSupportEvent {}
class CustomerSupportRefreshEvent extends CustomerSupportEvent {}
