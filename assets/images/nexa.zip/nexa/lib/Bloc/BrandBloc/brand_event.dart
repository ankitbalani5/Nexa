part of 'brand_bloc.dart';

@immutable
sealed class BrandEvent {}
class BrandFetchEvent extends BrandEvent {}
