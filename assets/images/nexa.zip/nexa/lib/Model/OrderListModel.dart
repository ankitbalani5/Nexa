class OrderListModel {
  String? status;
  String? message;
  List<Orders>? orders;

  OrderListModel({this.status, this.message, this.orders});

  OrderListModel.fromJson(Map<String, dynamic> json) {
    status = json['status'].toString();
    message = json['message'];
    if (json['orders'] != null) {
      orders = <Orders>[];
      json['orders'].forEach((v) {
        orders!.add(new Orders.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.orders != null) {
      data['orders'] = this.orders!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Orders {
  int? id;
  String? orderStatus;
  String? netAmount;
  String? orderId;
  int? quantity;
  String? orderDate;

  Orders(
      {this.id,
        this.orderStatus,
        this.netAmount,
        this.orderId,
        this.quantity,
        this.orderDate});

  Orders.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    orderStatus = json['order_status'];
    netAmount = json['net_amount'];
    orderId = json['order_id'];
    quantity = json['Quantity'];
    orderDate = json['order_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['order_status'] = this.orderStatus;
    data['net_amount'] = this.netAmount;
    data['order_id'] = this.orderId;
    data['Quantity'] = this.quantity;
    data['order_date'] = this.orderDate;
    return data;
  }
}
